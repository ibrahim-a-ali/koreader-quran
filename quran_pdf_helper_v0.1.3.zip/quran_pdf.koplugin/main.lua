--- Quran PDF Helper for KOReader.
-- Derived from Quran Helper v1.10 by zeeyado/quran-ebook.
-- PDF integration and independent plugin identity modified 2026-11-08.
-- SPDX-License-Identifier: GPL-3.0-only
--
-- Features:
--   1. Grammar dictionary lookup: intercepts long-press on ayah number markers
--      and prepends the surah name for unambiguous dictionary lookup.
--   2. Juz status bar: shows current juz and surah by default while reading,
--      with boundary indicator (*) at juz transitions.
--   3. Bundled cover: applies the included image on first open of a prepared
--      Quran PDF, using KOReader's normal custom-cover storage.
--
-- Grammar lookup flow:
--   1. onWordSelection: if selected text is Arabic-Indic digits, extract
--      surah number and name from TOC title and stash them.
--   2. onWordLookup: if we have a stashed surah and the text is
--      Arabic-Indic digits, return candidates for dictionary lookup:
--      - "An-Naba 2" (human-readable, for grammar dictionary headers)
--      - "078:002" (zero-padded, for backward compatibility)
--
-- Compatible TOC title formats:
--   Arabic-only: "٧٨ سورة النبإ"
--   Bilingual:   "78. An-Naba — سورة النبإ"
--
-- @module koplugin.quran_pdf
-- @alias Quran

local BD = require("ui/bidi")
local Blitbuffer = require("ffi/blitbuffer")
local DataStorage = require("datastorage")
local DictQuickLookup = require("ui/widget/dictquicklookup")
local Event = require("ui/event")
local Font = require("ui/font")
local Geom = require("ui/geometry")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan = require("ui/widget/horizontalspan")
local LuaSettings = require("luasettings")
local Math = require("optmath")
local Size = require("ui/size")
local TextBoxWidget = require("ui/widget/textboxwidget")
local SpinWidget = require("ui/widget/spinwidget")
local TextWidget = require("ui/widget/textwidget")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local Device = require("device")
local logger = require("logger")
local QuranPDF = require("quran_pdf_document")
local Screen = Device.screen
local _ = require("gettext")

local Quran = WidgetContainer:extend{
    name = "quran_pdf",
    pretty_name = "Quran PDF Helper",
}

-- A content revision, rather than the plugin version, lets later upgrades keep
-- a cover that the reader has deliberately chosen after this installation.
local BUNDLED_COVER_REVISION = "39bcd9802f466aa04ef584d6a08e0930b9b6046ade2cc84f3185659f253d358e"

-- UTF-8 character iterator pattern (start byte + continuation bytes).
-- Lua's byte-range patterns like [٠-٩] are broken for multi-byte UTF-8,
-- so we iterate characters and look them up in tables instead.
local UTF8_CHAR = ".[\128-\191]*"

-- Surah names for generating human-readable lookup keys.
-- Used when TOC has no Latin name (Arabic-only EPUBs).
-- Source: Quran.com API name_simple field.
local SURAH_NAMES = {
    "Al-Fatihah", "Al-Baqarah", "Ali 'Imran", "An-Nisa", "Al-Ma'idah",
    "Al-An'am", "Al-A'raf", "Al-Anfal", "At-Tawbah", "Yunus",
    "Hud", "Yusuf", "Ar-Ra'd", "Ibrahim", "Al-Hijr",
    "An-Nahl", "Al-Isra", "Al-Kahf", "Maryam", "Taha",
    "Al-Anbya", "Al-Hajj", "Al-Mu'minun", "An-Nur", "Al-Furqan",
    "Ash-Shu'ara", "An-Naml", "Al-Qasas", "Al-'Ankabut", "Ar-Rum",
    "Luqman", "As-Sajdah", "Al-Ahzab", "Saba", "Fatir",
    "Ya-Sin", "As-Saffat", "Sad", "Az-Zumar", "Ghafir",
    "Fussilat", "Ash-Shuraa", "Az-Zukhruf", "Ad-Dukhan", "Al-Jathiyah",
    "Al-Ahqaf", "Muhammad", "Al-Fath", "Al-Hujurat", "Qaf",
    "Adh-Dhariyat", "At-Tur", "An-Najm", "Al-Qamar", "Ar-Rahman",
    "Al-Waqi'ah", "Al-Hadid", "Al-Mujadila", "Al-Hashr", "Al-Mumtahanah",
    "As-Saf", "Al-Jumu'ah", "Al-Munafiqun", "At-Taghabun", "At-Talaq",
    "At-Tahrim", "Al-Mulk", "Al-Qalam", "Al-Haqqah", "Al-Ma'arij",
    "Nuh", "Al-Jinn", "Al-Muzzammil", "Al-Muddaththir", "Al-Qiyamah",
    "Al-Insan", "Al-Mursalat", "An-Naba", "An-Nazi'at", "'Abasa",
    "At-Takwir", "Al-Infitar", "Al-Mutaffifin", "Al-Inshiqaq", "Al-Buruj",
    "At-Tariq", "Al-A'la", "Al-Ghashiyah", "Al-Fajr", "Al-Balad",
    "Ash-Shams", "Al-Layl", "Ad-Duhaa", "Ash-Sharh", "At-Tin",
    "Al-'Alaq", "Al-Qadr", "Al-Bayyinah", "Az-Zalzalah", "Al-'Adiyat",
    "Al-Qari'ah", "At-Takathur", "Al-'Asr", "Al-Humazah", "Al-Fil",
    "Quraysh", "Al-Ma'un", "Al-Kawthar", "Al-Kafirun", "An-Nasr",
    "Al-Masad", "Al-Ikhlas", "Al-Falaq", "An-Nas",
}

-- Arabic surah names (without سورة prefix).
-- Source: Quran.com API name_arabic field.
local SURAH_NAMES_ARABIC = {
    "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة",
    "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
    "هود", "يوسف", "الرعد", "إبراهيم", "الحجر",
    "النحل", "الإسراء", "الكهف", "مريم", "طه",
    "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان",
    "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
    "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر",
    "يس", "الصافات", "ص", "الزمر", "غافر",
    "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية",
    "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
    "الذاريات", "الطور", "النجم", "القمر", "الرحمن",
    "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
    "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق",
    "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
    "نوح", "الجن", "المزمل", "المدثر", "القيامة",
    "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
    "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج",
    "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
    "الشمس", "الليل", "الضحى", "الشرح", "التين",
    "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
    "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل",
    "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
    "المسد", "الإخلاص", "الفلق", "الناس",
}

-- Ayah counts per surah (1-indexed) for prev/next navigation.
local SURAH_AYAH_COUNTS = {
    7, 286, 200, 176, 120, 165, 206, 75, 129, 109,  -- 1-10
    123, 111, 43, 52, 99, 128, 111, 110, 98, 135,   -- 11-20
    112, 78, 118, 64, 77, 227, 93, 88, 69, 60,      -- 21-30
    34, 30, 73, 54, 45, 83, 182, 88, 75, 85,        -- 31-40
    54, 53, 89, 59, 37, 35, 38, 29, 18, 45,         -- 41-50
    60, 49, 62, 55, 78, 96, 29, 22, 24, 13,         -- 51-60
    14, 11, 11, 18, 12, 12, 30, 52, 52, 44,         -- 61-70
    28, 28, 20, 56, 40, 31, 50, 40, 46, 42,         -- 71-80
    29, 19, 36, 25, 22, 17, 19, 26, 30, 20,         -- 81-90
    15, 21, 11, 8, 8, 19, 5, 8, 8, 11,              -- 91-100
    11, 8, 3, 9, 5, 4, 7, 3, 6, 3,                  -- 101-110
    5, 4, 5, 6,                                       -- 111-114
}

-- Reverse lookup: surah name -> surah number
local SURAH_NAME_TO_NUM = {}
for i, name in ipairs(SURAH_NAMES) do
    SURAH_NAME_TO_NUM[name] = i
end

-- ---------------------------------------------------------------------------
-- Juz boundary data (juz number -> {surah, ayah})
-- Source: Quran.com API v4 juz data (Hafs, Madinah Mushaf)
-- ---------------------------------------------------------------------------
local JUZ_BOUNDARIES = {
    { 1, 1 },    -- Juz 1:  Al-Fatihah 1
    { 2, 142 },  -- Juz 2:  Al-Baqarah 142
    { 2, 253 },  -- Juz 3:  Al-Baqarah 253
    { 3, 93 },   -- Juz 4:  Ali 'Imran 93
    { 4, 24 },   -- Juz 5:  An-Nisa 24
    { 4, 148 },  -- Juz 6:  An-Nisa 148
    { 5, 82 },   -- Juz 7:  Al-Ma'idah 82
    { 6, 111 },  -- Juz 8:  Al-An'am 111
    { 7, 88 },   -- Juz 9:  Al-A'raf 88
    { 8, 41 },   -- Juz 10: Al-Anfal 41
    { 9, 93 },   -- Juz 11: At-Tawbah 93
    { 11, 6 },   -- Juz 12: Hud 6
    { 12, 53 },  -- Juz 13: Yusuf 53
    { 15, 1 },   -- Juz 14: Al-Hijr 1
    { 17, 1 },   -- Juz 15: Al-Isra 1
    { 18, 75 },  -- Juz 16: Al-Kahf 75
    { 21, 1 },   -- Juz 17: Al-Anbya 1
    { 23, 1 },   -- Juz 18: Al-Mu'minun 1
    { 25, 21 },  -- Juz 19: Al-Furqan 21
    { 27, 56 },  -- Juz 20: An-Naml 56
    { 29, 46 },  -- Juz 21: Al-'Ankabut 46
    { 33, 31 },  -- Juz 22: Al-Ahzab 31
    { 36, 28 },  -- Juz 23: Ya-Sin 28
    { 39, 32 },  -- Juz 24: Az-Zumar 32
    { 41, 47 },  -- Juz 25: Fussilat 47
    { 46, 1 },   -- Juz 26: Al-Ahqaf 1
    { 51, 31 },  -- Juz 27: Adh-Dhariyat 31
    { 58, 1 },   -- Juz 28: Al-Mujadila 1
    { 67, 1 },   -- Juz 29: Al-Mulk 1
    { 78, 1 },   -- Juz 30: An-Naba 1
}

-- Juz Arabic names (traditional names from the first word/phrase)
local JUZ_NAMES_ARABIC = {
    "آلم",              -- 1
    "سيقول",            -- 2
    "تلك الرسل",        -- 3
    "لن تنالوا",        -- 4 (actually "كل الطعام" in some traditions)
    "والمحصنات",        -- 5
    "لا يحب الله",      -- 6
    "وإذا سمعوا",       -- 7
    "ولو أننا",         -- 8
    "قال الملأ",        -- 9
    "واعلموا",          -- 10
    "يعتذرون",          -- 11
    "وما من دابة",      -- 12
    "وما أبرئ",         -- 13
    "ربما",             -- 14 (actually "آلر")
    "سبحان",            -- 15
    "قال ألم",          -- 16
    "اقترب",            -- 17
    "قد أفلح",          -- 18
    "وقال الذين",       -- 19
    "أمن خلق",          -- 20 (actually "فما كان جواب" in some)
    "اتل ما أوحي",     -- 21
    "ومن يقنت",         -- 22
    "وما لي",           -- 23 (actually "وما أنزلنا")
    "فمن أظلم",         -- 24
    "إليه يرد",         -- 25
    "حم",               -- 26
    "قال فما خطبكم",    -- 27
    "قد سمع",           -- 28
    "تبارك",            -- 29
    "عم",               -- 30
}

-- Juz Latin names (transliterated traditional names)
local JUZ_NAMES_LATIN = {
    "Alif Lam Mim",
    "Sayaqul",
    "Tilkar-Rusul",
    "Lan Tanaalu",
    "Wal-Muhsanat",
    "La Yuhibbu-llah",
    "Wa Idha Sami'u",
    "Wa Lau Annana",
    "Qalal-Mala'u",
    "Wa'lamu",
    "Ya'tadhirun",
    "Wa Ma Min Dabbah",
    "Wa Ma Ubri'u",
    "Rubama",
    "Subhanalladhi",
    "Qal Alam",
    "Iqtaraba",
    "Qad Aflaha",
    "Wa Qalal-Ladhina",
    "Amman Khalaqa",
    "Utlu Ma Uhiya",
    "Wa Man Yaqnut",
    "Wa Ma Liya",
    "Faman Adhlamu",
    "Ilaihi Yuraddu",
    "Ha Mim",
    "Qala Fama Khatbukum",
    "Qad Sami'a",
    "Tabaraka",
    "'Amma",
}

-- Juz ordinal Arabic names (الجزء + ordinal number)
-- Used for the "الجزء الأول" display format.
local JUZ_ORDINAL_ARABIC = {
    "الأول",              -- 1
    "الثاني",             -- 2
    "الثالث",             -- 3
    "الرابع",             -- 4
    "الخامس",             -- 5
    "السادس",             -- 6
    "السابع",             -- 7
    "الثامن",             -- 8
    "التاسع",             -- 9
    "العاشر",             -- 10
    "الحادي عشر",         -- 11
    "الثاني عشر",         -- 12
    "الثالث عشر",         -- 13
    "الرابع عشر",         -- 14
    "الخامس عشر",         -- 15
    "السادس عشر",         -- 16
    "السابع عشر",         -- 17
    "الثامن عشر",         -- 18
    "التاسع عشر",         -- 19
    "العشرون",            -- 20
    "الحادي والعشرون",    -- 21
    "الثاني والعشرون",    -- 22
    "الثالث والعشرون",    -- 23
    "الرابع والعشرون",    -- 24
    "الخامس والعشرون",    -- 25
    "السادس والعشرون",    -- 26
    "السابع والعشرون",    -- 27
    "الثامن والعشرون",    -- 28
    "التاسع والعشرون",    -- 29
    "الثلاثون",           -- 30
}

--- Parse a dictionary lookup word to extract surah number and ayah number.
-- Matches "Surah_Name N" (human-readable) or "NNN:NNN" (zero-padded).
-- @return surah_num (integer or nil), ayah_num (integer or nil)
local function parseQuranKey(word)
    if not word then return nil, nil end

    -- Try zero-padded "NNN:NNN"
    local s, a = word:match("^(%d+):(%d+)$")
    if s and a then
        return tonumber(s), tonumber(a)
    end

    -- Try "Surah_Name N" — match last space + digits
    local name, ayah_str = word:match("^(.+)%s+(%d+)$")
    if name and ayah_str then
        local surah_num = SURAH_NAME_TO_NUM[name]
        if surah_num then
            return surah_num, tonumber(ayah_str)
        end
    end

    return nil, nil
end

-- Map Arabic-Indic digits (2-byte UTF-8) to Western digits
local DIGIT_MAP = {
    ["٠"] = "0", ["١"] = "1", ["٢"] = "2", ["٣"] = "3", ["٤"] = "4",
    ["٥"] = "5", ["٦"] = "6", ["٧"] = "7", ["٨"] = "8", ["٩"] = "9",
}

--- Check if a string is a QCF glyph code (Arabic Presentation Forms-A/B).
-- QCF fonts encode each word as a single glyph in the U+FB50–U+FDFF or
-- U+FE70–U+FEFF range.  These are not real Arabic text — they're opaque
-- codepoints that only render correctly with the matching per-page font.
local function isQcfGlyph(s)
    if not s or s == "" then return false end
    -- QCF glyph codes are 1–2 characters in Presentation Forms ranges.
    -- In UTF-8: U+FB50 = EF AD 90, U+FDFF = EF B7 BF, U+FE70 = EF B9 B0, U+FEFF = EF BB BF.
    -- Check first char: byte 1 = 0xEF (239), byte 2 in [0xAD..0xB7] or [0xB9..0xBB].
    local b1, b2 = s:byte(1, 2)
    if b1 == 0xEF and b2 then
        if (b2 >= 0xAD and b2 <= 0xB7) or (b2 >= 0xB9 and b2 <= 0xBB) then
            return true
        end
    end
    return false
end

--- Read QCF word info from the element at an XPointer.
-- Uses CREngine's getHTMLFromXPointer with EXTRA_OFFSETS_SELECTORS flag
-- to retrieve the HTML of the block-level parent, then finds the specific
-- <span> containing the selected glyph to extract its attributes.
-- @param document CreDocument handle
-- @param xpointer XPointer of the selected text
-- @param glyph_text The selected QCF glyph string (used to find the right span)
-- @return uthmani_text (string|nil), surah_num (int|nil), ayah_num (int|nil)
--   Regular word: uthmani_text is set, surah/ayah are nil
--   End marker:   uthmani_text is nil, surah/ayah are set
--   Failure:      all nil
local function readQcfWordInfo(document, pos0, pos1)
    if not document or not pos0 or not pos1 then return nil end
    -- from_root_node=true wraps the selected range with its parent elements,
    -- giving us the enclosing <span> with data-uthmani and id attributes.
    -- 0x8000 = WRITENODEEX_EXTRA_OFFSETS_SELECTORS (preserves data-* attrs).
    local html = document:getHTMLFromXPointers(pos0, pos1, 0x8000, true)
    if not html then return nil end

    -- Regular word: has data-uthmani attribute
    local uthmani = html:match('data%-uthmani="([^"]*)"')
    if uthmani then return uthmani, nil, nil end

    -- Ayah-end marker: has id="...ayah-{surah}-{ayah}" (CREngine prefixes the id)
    local surah, ayah = html:match('ayah%-(%d+)%-(%d+)')
    if surah and ayah then return nil, tonumber(surah), tonumber(ayah) end

    return nil
end

--- Check if a string consists only of Arabic-Indic digits.
local function isArabicIndicDigits(s)
    if not s or s == "" then return false end
    for c in s:gmatch(UTF8_CHAR) do
        if not DIGIT_MAP[c] then
            return false
        end
    end
    return true
end

--- Convert Arabic-Indic numeral string to Western integer.
local function arabicIndicToInt(s)
    local western = ""
    for c in s:gmatch(UTF8_CHAR) do
        if DIGIT_MAP[c] then
            western = western .. DIGIT_MAP[c]
        end
    end
    if western == "" then return nil end
    return tonumber(western)
end

--- Normalize QPC-repurposed tanween codepoints to standard Arabic equivalents.
-- QPC uses three codepoints with custom glyphs in its font that render
-- incorrectly in standard Arabic fonts (e.g. KOReader dictionary popup):
--   U+0657 (inverted damma)      → U+064B (fathatan)
--   U+065E (fatha with two dots) → U+064C (dammatan)
--   U+0656 (subscript alef)      → U+064D (kasratan)
local function normalizeQpcTanween(text)
    text = text:gsub("\xD9\x97", "\xD9\x8B")
    text = text:gsub("\xD9\x9E", "\xD9\x8C")
    text = text:gsub("\xD9\x96", "\xD9\x8D")
    return text
end

--- Extract trailing Arabic-Indic digits from a string.
-- In inline layout, the word joiner (U+2060) prevents word boundary detection
-- from splitting Arabic text and the ayah number, so the selected "word" may
-- include preceding Arabic text (e.g., "بِسْمِ٢٥٥"). This extracts the
-- trailing digit sequence.
-- Also handles Western digits (after KOReader's cleanSelection).
-- @return digit string (Arabic-Indic or Western) or nil
local function extractTrailingDigits(s)
    if not s or s == "" then return nil end
    -- First try: purely Arabic-Indic digits (no extraction needed)
    if isArabicIndicDigits(s) then return s end
    -- Extract trailing Arabic-Indic digits
    local chars = {}
    for c in s:gmatch(UTF8_CHAR) do
        table.insert(chars, c)
    end
    local digits = {}
    for i = #chars, 1, -1 do
        if DIGIT_MAP[chars[i]] then
            table.insert(digits, 1, chars[i])
        else
            break
        end
    end
    if #digits > 0 then
        return table.concat(digits)
    end
    -- Try trailing Western digits (KOReader may normalize)
    local western = s:match("(%d+)$")
    if western then return western end
    return nil
end

--- Extract surah number and name from a TOC title string.
-- @param title TOC title string
-- @return surah number (integer) or nil, surah name (string) or nil
local function extractSurahInfo(title)
    if not title or title == "" then return nil, nil end

    -- Bilingual: "78. An-Naba — سورة النبإ"
    local w_num, name = title:match("^(%d+)%.%s*(.-)%s*—")
    if w_num and name then
        return tonumber(w_num), name:match("^%s*(.-)%s*$")
    end
    -- Bilingual without Arabic part
    w_num, name = title:match("^(%d+)%.%s*(.+)")
    if w_num and name then
        return tonumber(w_num), name:match("^%s*(.-)%s*$")
    end

    -- Arabic-only: "٧٨ سورة النبإ"
    local prefix = ""
    for c in title:gmatch(UTF8_CHAR) do
        if DIGIT_MAP[c] then
            prefix = prefix .. c
        else
            break
        end
    end
    if prefix ~= "" then
        return arabicIndicToInt(prefix), nil
    end

    return nil, nil
end

-- ---------------------------------------------------------------------------
-- Text mode viewer (ScrollTextWidget alternative to ScrollHtmlWidget)
-- ---------------------------------------------------------------------------

-- Dictionaries whose formatting relies on MuPDF (tables, structured layout).
-- Everything else (tafsir, word-by-word, surah overview) defaults to text mode.
local HTML_PREFERRED_DICTS = {
    ["Quran Grammar"]        = true,  -- grammar combined
    ["Quran Grammar (Lite)"] = true,  -- grammar lite
}

--- Check whether a dictionary should default to HTML/MuPDF rendering.
-- @param dict_name string StarDict bookname
-- @return boolean true if this dict benefits from HTML rendering
local function isHtmlPreferred(dict_name)
    return dict_name and HTML_PREFERRED_DICTS[dict_name] or false
end

-- PTF markers for inline bold in ScrollTextWidget (via TextBoxWidget).
local PTF_HEADER = TextBoxWidget.PTF_HEADER
local PTF_BOLD_START = TextBoxWidget.PTF_BOLD_START
local PTF_BOLD_END = TextBoxWidget.PTF_BOLD_END

--- Convert HTML definition text to plain text with PTF bold markers.
-- Strips tags, converts <b>/<strong> to PTF bold, preserves structure.
-- @param html string HTML content from StarDict definition
-- @return string plain text with PTF bold markers
local function htmlToText(html)
    if not html or html == "" then return "" end

    -- Remove hidden ref comments used by per-instance word matching
    local text = html:gsub("<!%-%-.-%-%->\n?", "")

    -- Convert <br> and <br/> to newlines
    text = text:gsub("<br%s*/?>", "\n")

    -- Convert block elements to double newlines (paragraph breaks)
    text = text:gsub("</?p[^>]*>", "\n")
    text = text:gsub("</?div[^>]*>", "\n")
    text = text:gsub("</?h%d[^>]*>", "\n")
    text = text:gsub("<hr[^>]*>", "\n")

    -- Convert <b> and <strong> to PTF bold markers
    text = text:gsub("<b[^a-z>]*>", PTF_BOLD_START)
    text = text:gsub("</b>", PTF_BOLD_END)
    text = text:gsub("<strong[^>]*>", PTF_BOLD_START)
    text = text:gsub("</strong>", PTF_BOLD_END)

    -- Strip all remaining HTML tags
    text = text:gsub("<[^>]+>", "")

    -- Decode common HTML entities
    text = text:gsub("&amp;", "&")
    text = text:gsub("&lt;", "<")
    text = text:gsub("&gt;", ">")
    text = text:gsub("&quot;", '"')
    text = text:gsub("&#39;", "'")
    text = text:gsub("&nbsp;", " ")
    text = text:gsub("&#x200[eE];", "\u{200E}") -- LRM
    text = text:gsub("&#x200[fF];", "\u{200F}") -- RLM

    -- Collapse multiple blank lines into at most two newlines
    text = text:gsub("\n[ \t]*\n[ \t]*\n+", "\n\n")
    -- Trim leading/trailing whitespace
    text = text:gsub("^%s+", ""):gsub("%s+$", "")

    -- Prepend PTF header if we have any bold markers
    if text:find(PTF_BOLD_START, 1, true) then
        text = PTF_HEADER .. text
    end

    return text
end

--- Create a TXT ON/OFF toggle button for Quran popups.
-- Toggles between HTML (MuPDF) and plain-text (TextBoxWidget) rendering
-- by manipulating DQL's own is_html flag and calling update().  DQL's
-- native _instantiateScrollWidget / update flow handles all widget
-- lifecycle — we never create or free widgets ourselves.
-- @param dict_popup DictQuickLookup instance
-- @return table button spec for insertion into button row
local function textModeButton(dict_popup)
    return {
        id = "text_mode",
        text_func = function()
            if dict_popup._quran_pdf_text_mode then
                return _("TXT ON")
            else
                return _("TXT OFF")
            end
        end,
        callback = function()
            -- Toggle: set manual override, opposite of current state
            local new_mode = not dict_popup._quran_pdf_text_mode
            dict_popup._quran_pdf_text_override = new_mode
            -- Restore original HTML values so update() starts clean
            if not new_mode then
                local result = dict_popup.results and dict_popup.results[dict_popup.dict_index]
                if result then
                    dict_popup.is_html = result.is_html
                    dict_popup.definition = result.definition
                end
            end
            dict_popup:update()
            -- Refresh button label
            if dict_popup.button_table then
                local btn = dict_popup.button_table:getButtonById("text_mode")
                if btn then
                    local label = dict_popup._quran_pdf_text_mode
                        and _("TXT ON") or _("TXT OFF")
                    btn:setText(label, btn.width)
                end
            end
        end,
    }
end

-- ---------------------------------------------------------------------------
-- Monkey-patches (applied once at first plugin init)
-- ---------------------------------------------------------------------------

--- Resize a DictQuickLookup popup after init to use ~65% of available height.
-- Called from the monkey-patched init when _quran_pdf_popup flag is set.
-- The default dict popup uses ~35% height. We expand the definition area
-- and update the widget tree so the larger window renders correctly.
local function resizeToMedium(dql)
    local margin_top = Size.margin.default
    local margin_bottom = Size.margin.default
    if dql.ui and dql.ui.view and dql.ui.view.footer_visible then
        margin_bottom = margin_bottom + dql.ui.view.footer:getHeight()
    end
    local actual_avail = Screen:getHeight() - margin_top - margin_bottom

    -- Target: ~65% of available height for the definition area
    local target_def = math.floor(actual_avail * 0.65)
    local nb_lines = Math.round(target_def / dql.definition_line_height)
    local new_def = nb_lines * dql.definition_line_height

    if new_def <= dql.definition_height then
        return -- already at or above target, skip
    end

    local old_def = dql.definition_height
    dql.definition_height = new_def
    dql.height = dql.height + (new_def - old_def)

    -- Recreate scroll widget with new height
    if dql.text_widget and dql.text_widget.free then
        dql.text_widget:free()
    end
    dql:_instantiateScrollWidget()
    dql.definition_widget[1] = dql.text_widget

    -- Update the CenterContainer wrapping definition_widget
    local vg = dql.dict_frame[1] -- VerticalGroup
    if vg then
        for i = 1, #vg do
            if type(vg[i]) == "table" and vg[i][1] == dql.definition_widget then
                vg[i].dimen.h = dql.definition_widget:getSize().h
                break
            end
        end
    end

    -- Recompute region so window centers in actual available space
    dql.region = Geom:new{
        x = 0,
        y = margin_top,
        w = Screen:getWidth(),
        h = actual_avail,
    }
    dql.align = "center"
    dql[1].dimen = dql.region
    dql[1].align = dql.align
end

-- Active plugin instance for use inside monkeypatches. Patches are applied
-- once per session, but a new plugin instance is created for every document,
-- so patches must not close over `self` — they go through this upvalue,
-- refreshed on every Quran:init().
local _active_quran_pdf = nil

local function applyMonkeyPatches(quran)
    _active_quran_pdf = quran
    if DictQuickLookup._quran_pdf_patched then return end
    DictQuickLookup._quran_pdf_patched = true

    -- Patch 1: DictQuickLookup.init — resize Quran popups to medium height
    -- and apply content-type-aware text mode via update() (Patch 2).
    local orig_init = DictQuickLookup.init
    DictQuickLookup.init = function(self_dql, ...)
        orig_init(self_dql, ...)
        if self_dql._quran_pdf_popup then
            resizeToMedium(self_dql)
            -- Re-run update so Patch 2 auto-determines rendering mode
            self_dql:update()
        end
    end

    -- Patch 2: DictQuickLookup.update — auto-select rendering mode.
    -- Prose dictionaries (tafsir, word-by-word) default to text mode for
    -- better Arabic shaping; structured dictionaries (grammar) stay HTML.
    -- Manual toggle via TXT button sets _quran_pdf_text_override, which is
    -- cleared when the dictionary changes so the new dict gets its default.
    local orig_update = DictQuickLookup.update
    DictQuickLookup.update = function(self_dql, ...)
        if self_dql._quran_pdf_popup then
            local result = self_dql.results and self_dql.results[self_dql.dict_index]
            if result then
                -- Reset manual override when dictionary changes
                if self_dql._quran_pdf_last_dict ~= result.dict then
                    self_dql._quran_pdf_text_override = nil
                    self_dql._quran_pdf_last_dict = result.dict
                end
                -- Determine mode: manual override wins, else content-type default
                if self_dql._quran_pdf_text_override ~= nil then
                    self_dql._quran_pdf_text_mode = self_dql._quran_pdf_text_override
                else
                    self_dql._quran_pdf_text_mode = not isHtmlPreferred(result.dict)
                end
                -- Apply text mode
                if self_dql._quran_pdf_text_mode then
                    self_dql.is_html = false
                    self_dql.definition = htmlToText(result.definition or "")
                end
            end
        end
        orig_update(self_dql, ...)
        -- Update TXT button label to reflect the (possibly auto-changed) mode
        if self_dql._quran_pdf_popup and self_dql.button_table then
            local btn = self_dql.button_table:getButtonById("text_mode")
            if btn then
                local label = self_dql._quran_pdf_text_mode
                    and _("TXT ON") or _("TXT OFF")
                btn:setText(label, btn.width)
            end
        end
    end

    -- Patch 3: ReaderDictionary.showDict — per-instance word filtering and
    -- in-place update for Quran nav. Filtering happens here (before the popup
    -- is built) so it works on every KOReader version — the DictButtonsReady
    -- event this used to rely on was removed upstream in May 2026 (#15184).
    local ReaderDictionary = require("apps/reader/modules/readerdictionary")
    local orig_showDict = ReaderDictionary.showDict
    ReaderDictionary.showDict = function(self_dict, word, results, boxes, link, dict_close_callback)
        if not _active_quran_pdf or not _active_quran_pdf:_getPDF() then
            return orig_showDict(self_dict, word, results, boxes, link, dict_close_callback)
        end
        if _active_quran_pdf and results then
            results = _active_quran_pdf:_filterWordResultsByPosition(results)
        end
        local target = DictQuickLookup._quran_pdf_update_popup
        if target and results and results[1] then
            DictQuickLookup._quran_pdf_update_popup = nil
            -- Update existing popup in-place
            target.results = results
            target.word = word
            -- Stay in the same dictionary the user was viewing
            local target_index = 1
            local dict_name = target._quran_pdf_dict_name
            if dict_name then
                for i, r in ipairs(results) do
                    if r.dict == dict_name then
                        target_index = i
                        break
                    end
                end
            end
            -- changeDictionary() → update() → Patch 2 handles text mode
            target:changeDictionary(target_index)
            self_dict:dismissLookupInfo()
            return
        end
        return orig_showDict(self_dict, word, results, boxes, link, dict_close_callback)
    end

    -- Patch 4: ReaderDictionary.onLookupWord — normalize QPC tanween BEFORE
    -- the word enters the dictionary lookup pipeline.  This makes the normalized
    -- word the primary lookup term (exact match, correct popup header rendering)
    -- instead of an appended candidate that loses to the original's fuzzy match.
    local orig_onLookupWord = ReaderDictionary.onLookupWord
    ReaderDictionary.onLookupWord = function(self_dict, word, is_sane, boxes, highlight, ...)
        if _active_quran_pdf and _active_quran_pdf:_getPDF() then
            word = _active_quran_pdf:_preparePDFLookup(word, highlight)
            if word then word = normalizeQpcTanween(word) end
        end
        return orig_onLookupWord(self_dict, word, is_sane, boxes, highlight, ...)
    end

    -- Patch 5: DictQuickLookup.buildButtonLayout — KOReader ≥ 2026.05.
    -- Upstream #15184 (ed695fe34) removed the DictButtonsReady event and
    -- replaced it with a button-pool layout system. On those versions we
    -- replace the layout wholesale for Quran popups; non-Quran popups fall
    -- through to the stock layout. Older KOReader keeps using the
    -- Quran:onDictButtonsReady event handler instead — buildButtonLayout
    -- doesn't exist there, so this patch is skipped.
    if DictQuickLookup.buildButtonLayout then
        local orig_buildButtonLayout = DictQuickLookup.buildButtonLayout
        DictQuickLookup.buildButtonLayout = function(self_dql, ...)
            if _active_quran_pdf then
                local rows = {}
                if _active_quran_pdf:_setupQuranPopupButtons(self_dql, rows) then
                    return rows
                end
            end
            return orig_buildButtonLayout(self_dql, ...)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Plugin methods
-- ---------------------------------------------------------------------------

function Quran:init()
    self._pdf = nil
    DictQuickLookup._quran_pdf_next_lookup = nil
    DictQuickLookup._quran_pdf_update_popup = nil
    self._stashed_surah = nil
    self._stashed_surah_name = nil
    self._stashed_surah_glyph = nil
    self._stashed_qcf_ayah = nil
    self._last_ayah_surah = nil
    self._last_ayah_num = nil
    self._last_overview_surah = nil
    self._cached_juz = nil       -- cached juz number for current page
    self._cached_boundary = nil  -- cached boundary flag for current page
    self._cached_pageno = nil    -- page number the juz cache is valid for
    self._cached_surah = nil     -- cached surah number for current page
    self._cached_surah_pg = nil  -- page number the surah cache is valid for
    self._juz_toc_pages = nil    -- juz TOC entry -> page mapping
    self._is_quran_book = nil    -- true only for a prepared Quran PDF
    self._status_bar_registered = false
    applyMonkeyPatches(self)

    -- Persistent settings
    self.settings = LuaSettings:open(DataStorage:getSettingsDir() .. "/quran_pdf.lua")

    -- Juz status bar content function (closure captures self)
    self.additional_footer_content_func = function()
        if not self._is_quran_book then return end
        if not self.settings:nilOrTrue("show_juz_in_footer") then return end
        return self:_getJuzFooterString()
    end

    -- Alt status bar (header) content function
    self.additional_header_content_func = function()
        if not self._is_quran_book then return end
        if not self.settings:nilOrTrue("show_juz_in_header") then return end
        return self:_getJuzHeaderString()
    end

    self.ui.menu:registerToMainMenu(self)
end

--- Detect whether the current book is a quran-ebook EPUB.
-- Checks dc:subject (exposed as keywords by CRe) for "Quran" and
-- dc:publisher for "quran-ebook".  This prevents the plugin from
-- injecting juz/surah status into unrelated books.
--- Return a prepared PDF adapter, or nil for EPUBs and unrelated PDFs.
function Quran:_getPDF()
    if self._pdf == nil then
        self._pdf = QuranPDF.new(self.ui and self.ui.document) or false
    end
    return self._pdf or nil
end

--- PDF word selection does not pass through LanguageSupport's CRE-only
-- selection callbacks. Feed the native selection into the same Quran lookup
-- state machine before dictionary cleanup/search, preserving all popup logic.
function Quran:_preparePDFLookup(word, highlight)
    if not self:_getPDF() then return word end
    if not highlight or not highlight.selected_text then
        self._stashed_pdf_reference = nil
        self._stashed_word_pos0, self._stashed_word_pos1 = nil, nil
        return word
    end
    DictQuickLookup._quran_pdf_next_lookup = nil
    DictQuickLookup._quran_pdf_update_popup = nil
    self:onWordSelection(highlight.selected_text)
    local candidates = self:onWordLookup({text=word})
    if candidates and candidates[1] then return candidates[1] end
    return word
end

function Quran:_detectQuranBook()
    return self:_getPDF() ~= nil
end

--- Clear both library caches and use KOReader's normal library refresh event.
-- ReaderReady can run while FileManager is hidden, so also perform this when
-- closing the document after a cover installation or migration.
function Quran:_refreshLibraryCover(file)
    local refreshed = true
    local manager = package.loaded["bookinfomanager"]
    if manager and type(manager.deleteBookInfo) == "function" then
        local ok, err = pcall(manager.deleteBookInfo, manager, file)
        if not ok then
            refreshed = false
            logger.warn("quran_pdf.koplugin: cover cache refresh failed:", err)
        end
    else
        -- CoverBrowser may be disabled. Retry the DB migration on a later open
        -- rather than declaring an old, unloaded cache up to date.
        refreshed = false
    end
    local booklist = package.loaded["ui/widget/booklist"]
    if booklist and type(booklist.resetBookInfoCache) == "function" then
        local ok, err = pcall(booklist.resetBookInfoCache, file)
        if not ok then
            refreshed = false
            logger.warn("quran_pdf.koplugin: book list refresh failed:", err)
        end
    end
    for _, event in ipairs({
        Event:new("InvalidateMetadataCache", file),
        Event:new("BookMetadataChanged"),
    }) do
        local ok, err = pcall(UIManager.broadcastEvent, UIManager, event)
        if not ok then
            refreshed = false
            logger.warn("quran_pdf.koplugin: cover refresh event failed:", err)
        end
    end
    return refreshed
end

--- Install or migrate the bundled cover, using KOReader's metadata location.
-- v0.1.2 skipped this path for an existing custom cover, leaving the old image
-- and the cached first page in place. Refresh an existing cover on upgrade too.
function Quran:_ensureBundledCover()
    if not self._is_quran_book then return end
    local doc_settings = self.ui and self.ui.doc_settings
    local file = self.ui and self.ui.document and self.ui.document.file
    if not doc_settings or not file or not self.path then return end

    local ok, refresh_needed = pcall(function()
        local existing = doc_settings:findCustomCoverFile(file)
        if not existing or doc_settings:readSetting("quran_pdf_cover_revision") ~= BUNDLED_COVER_REVISION then
            if not doc_settings:flushCustomCover(file, self.path .. "/cover.png") then
                return false
            end
            -- If an older cover uses another extension, KOReader's directory
            -- scan could choose it instead of the newly written cover.png.
            -- Remove that obsolete cover only after the new image is saved.
            if existing and not existing:match("/cover%.png$") then
                local removed, err = os.remove(existing)
                if not removed then
                    logger.warn("quran_pdf.koplugin: old cover could not be replaced:", err)
                    return false
                end
            end
            doc_settings:getCustomCoverFile(true)
            doc_settings:saveSetting("quran_pdf_cover_revision", BUNDLED_COVER_REVISION)
            self._quran_pdf_cover_refresh_pending = file
        end
        return self._quran_pdf_cover_refresh_pending ~= nil
            or doc_settings:readSetting("quran_pdf_cover_cache_revision") ~= BUNDLED_COVER_REVISION
    end)
    if not ok then
        logger.warn("quran_pdf.koplugin: could not install bundled cover:", refresh_needed)
        return
    end
    if refresh_needed then
        self._quran_pdf_cover_refresh_pending = file
        if self:_refreshLibraryCover(file) then
            doc_settings:saveSetting("quran_pdf_cover_cache_revision", BUNDLED_COVER_REVISION)
        end
    end
end

--- Keep upstream v1.10's unconditionally parsed popup keys from claiming
-- prepared-PDF lookups. Only the current document's instance is guarded;
-- no upstream source, settings or EPUB instance is changed. ReaderUI exposes
-- loaded plugin instances by their original module name (ui.quran).
function Quran:_guardUpstreamForPDF()
    if not self:_getPDF() or self._upstream_pdf_guard then return end
    local upstream = self.ui and self.ui.quran
    if not upstream or upstream == self then return end
    self._upstream_pdf_guard = {
        instance = upstream,
        detect = rawget(upstream, "_detectQuranBook"),
        buttons = rawget(upstream, "_setupQuranPopupButtons"),
    }
    upstream._detectQuranBook = function() return false end
    upstream._setupQuranPopupButtons = function() return nil end
    upstream._is_quran_book = false
    upstream._header_overlay_enabled = false
    if upstream.additional_footer_content_func and upstream._removeFooterContent then
        upstream:_removeFooterContent()
    end
end

--- Register status bar content after document is ready.
-- Deferred from init() because ui.view and ui.crelistener may not
-- be available yet during plugin initialization.
function Quran:onReaderReady()
    if self._status_bar_registered then return end
    self._status_bar_registered = true

    self._is_quran_book = self:_detectQuranBook()
    self:_guardUpstreamForPDF()
    self:_ensureBundledCover()

    logger.dbg("quran_pdf.koplugin: onReaderReady — view:", self.ui.view and "yes" or "nil",
                "crelistener:", self.ui.crelistener and "yes" or "nil",
                "quran_book:", self._is_quran_book and "yes" or "no")

    if self._is_quran_book and self.settings:nilOrTrue("show_juz_in_footer") then
        self:_addFooterContent()
    end
    -- Header overlay (pure Lua, replaces CREngine alt status bar approach)
    if self._is_quran_book then
        self:_setupHeaderOverlay()
        self._header_overlay_enabled = self.settings:isTrue("show_header_overlay")
    end
end

--- [LEGACY] Re-apply header space hack when alt status bar is toggled.
-- Kept for reference but no longer called — overlay approach doesn't need this.
function Quran:onSetStatusLine()
    -- The overlay header is independent of CREngine's alt status bar,
    -- so no action needed here.
end

-- PDF selections arrive through ReaderDictionary, not CRE language callbacks.
-- Leave Arabic EPUB handling to the original Quran Helper.
function Quran:supportsLanguage(language_code)
    return false
end

--- Find surah number and name for a given position by searching the TOC.
function Quran:_findSurahForPosition(pos)
    local pdf = self:_getPDF()
    if pdf and type(pos) == "table" then
        local hit = pdf:selection({pos0=pos,pos1=pos})
        local context = pdf:page(pos.page)
        local surah = hit and hit.surah or context and context.s
        return surah, surah and SURAH_NAMES[surah]
    end
    local toc = self.ui.toc
    if not toc then return nil, nil end

    toc:fillToc()
    local toc_list = toc.toc
    if not toc_list or #toc_list == 0 then return nil, nil end

    local doc = self.ui.document
    if not doc then return nil, nil end

    local pageno = doc:getPageFromXPointer(pos)

    local best_surah = nil
    local best_name = nil
    for _, entry in ipairs(toc_list) do
        if entry.page and entry.page <= pageno and entry.title then
            local title = toc:cleanUpTocTitle(entry.title)
            local surah_num, surah_name = extractSurahInfo(title)
            if surah_num then
                best_surah = surah_num
                best_name = surah_name
            end
        end
    end

    if best_surah then
        logger.dbg("quran_pdf.koplugin: page", pageno, "-> surah", best_surah, best_name)
    end
    return best_surah, best_name
end

--- Called during word selection (long-press).
function Quran:onWordSelection(args)
    if not self:_getPDF() then return nil end
    self._stashed_surah = nil
    self._stashed_surah_name = nil
    self._stashed_surah_glyph = nil
    self._stashed_qcf_uthmani = nil
    self._stashed_qcf_ayah = nil
    -- Clear nav state from previous Quran popup so it doesn't leak
    -- into subsequent non-Quran lookups (_setupQuranPopupButtons would
    -- otherwise patch a normal word popup's buttons away).
    self._last_ayah_surah = nil
    self._last_ayah_num = nil
    self._last_overview_surah = nil

    -- Stash raw XPointers for per-instance dictionary matching
    -- (no CREngine calls here — detection deferred to the showDict filter)
    self._stashed_word_pos0 = args.pos0
    self._stashed_word_pos1 = args.pos1
    self._stashed_pdf_reference = nil

    local pdf = self:_getPDF()
    if pdf then
        local hit = pdf:selection(args)
        if hit then
            if hit.ayah then self._stashed_pdf_reference = {hit.surah,hit.ayah} end
            if hit.kind == "surah" then
                self._stashed_surah_glyph = hit.surah
            elseif hit.kind == "ayah" then
                self._stashed_surah = hit.surah
                self._stashed_surah_name = SURAH_NAMES[hit.surah]
                self._stashed_qcf_ayah = hit.ayah
            elseif hit.kind == "word" then
                self._stashed_qcf_uthmani = hit.text
            end
        end
        return nil
    end

    local text = args.text
    logger.dbg("quran_pdf.koplugin: onWordSelection text='" .. (text or "nil") .. "'")

    -- Detect surah glyph long-press: trigger text is "surahNNNsurah-icon" (e.g. "surah002surah-icon").
    -- Also matches legacy "surahNNNx" (V2) and bare "surahNNN" formats.
    -- Returns the surah name as lookup candidate for surah overview dictionary.
    if text then
        local surah_num_str = text:match("^surah(%d+)")
        if surah_num_str then
            local surah_num = tonumber(surah_num_str)
            if surah_num and surah_num >= 1 and surah_num <= 114 then
                local name = SURAH_NAMES[surah_num]
                logger.dbg("quran_pdf.koplugin: surah glyph detected, surah", surah_num, name)
                self._stashed_surah_glyph = surah_num
                return nil
            end
        end
    end

    -- QCF glyph: the selected text is an opaque Presentation Forms codepoint.
    -- Read the real Arabic text (word) or ayah info (end marker) from span attrs.
    if isQcfGlyph(text) then
        local uthmani, surah, ayah = readQcfWordInfo(self.ui.document, args.pos0, args.pos1)
        if uthmani then
            logger.dbg("quran_pdf.koplugin: QCF word → data-uthmani='" .. uthmani .. "'")
            self._stashed_qcf_uthmani = uthmani
        elseif surah and ayah then
            logger.dbg("quran_pdf.koplugin: QCF end marker → surah=" .. surah .. " ayah=" .. ayah)
            self._stashed_surah = surah
            self._stashed_surah_name = SURAH_NAMES[surah]
            self._stashed_qcf_ayah = ayah
        else
            logger.dbg("quran_pdf.koplugin: QCF glyph but no word info found")
        end
        return nil
    end

    -- In inline layout, word joiner (U+2060) may cause the selection to include
    -- preceding Arabic text along with the ayah digits. Extract trailing digits.
    local digit_str = extractTrailingDigits(text)
    if not digit_str then
        logger.dbg("quran_pdf.koplugin: no trailing digits found, skipping")
        return nil
    end

    logger.dbg("quran_pdf.koplugin: extracted digits='" .. digit_str .. "'")

    local surah_num, surah_name = self:_findSurahForPosition(args.pos0)
    if surah_num then
        logger.dbg("quran_pdf.koplugin: ayah " .. digit_str .. " in surah " .. surah_num .. " " .. (surah_name or "(no name)"))
        self._stashed_surah = surah_num
        self._stashed_surah_name = surah_name
    else
        logger.dbg("quran_pdf.koplugin: could not find surah for ayah " .. digit_str)
    end

    return nil
end

--- Called during dictionary lookup.
function Quran:onWordLookup(args)
    if not self:_getPDF() then return nil end
    local text = args.text
    logger.dbg("quran_pdf.koplugin: onWordLookup text='" .. (text or "nil") .. "'")

    -- QCF glyph lookup: substitute real Arabic text from data-uthmani attribute
    local qcf_uthmani = self._stashed_qcf_uthmani
    self._stashed_qcf_uthmani = nil
    if qcf_uthmani then
        logger.dbg("quran_pdf.koplugin: QCF word lookup:", qcf_uthmani)
        return { qcf_uthmani }
    end

    -- Surah glyph lookup: return surah name as candidate for overview dictionary
    local surah_glyph = self._stashed_surah_glyph
    self._stashed_surah_glyph = nil
    if surah_glyph then
        local name = SURAH_NAMES[surah_glyph]
        if name then
            logger.dbg("quran_pdf.koplugin: surah overview lookup:", name)
            self._last_overview_surah = surah_glyph
            DictQuickLookup._quran_pdf_next_lookup = true
            return { name }
        end
        return nil
    end

    local surah = self._stashed_surah
    local surah_name = self._stashed_surah_name
    local qcf_ayah = self._stashed_qcf_ayah
    self._stashed_surah = nil
    self._stashed_surah_name = nil
    self._stashed_qcf_ayah = nil

    if not surah then
        logger.dbg("quran_pdf.koplugin: no stashed surah, skipping")
        return nil
    end

    -- QCF ayah-end markers: ayah number already extracted from id attribute
    local ayah = qcf_ayah
    if not ayah then
        -- Extract trailing digits (handles inline layout where Arabic text
        -- is joined to the ayah number, and KOReader digit normalization)
        local digit_str = extractTrailingDigits(text)
        if not digit_str then
            logger.dbg("quran_pdf.koplugin: no trailing digits in lookup text, skipping")
            return nil
        end

        if isArabicIndicDigits(digit_str) then
            ayah = arabicIndicToInt(digit_str)
        else
            ayah = tonumber(digit_str)
        end
    end
    if not ayah then return nil end

    logger.dbg("quran_pdf.koplugin: lookup surah=" .. surah .. " ayah=" .. ayah)

    local candidates = {}
    local name = surah_name or SURAH_NAMES[surah]
    if name then
        table.insert(candidates, name .. " " .. ayah)
    end
    table.insert(candidates, string.format("%03d:%03d", surah, ayah))

    -- Stash for _setupQuranPopupButtons
    self._last_ayah_surah = surah
    self._last_ayah_num = ayah

    -- Flag next DictQuickLookup for medium-height Quran window
    DictQuickLookup._quran_pdf_next_lookup = true

    logger.dbg("quran_pdf.koplugin: lookup candidates:", candidates)
    return candidates
end

--- Navigate to a specific ayah. Updates the popup in-place.
function Quran:_lookupAyah(surah, ayah, dict_popup)
    local name = SURAH_NAMES[surah]
    if not name then return end

    local key = name .. " " .. ayah
    logger.dbg("quran_pdf.koplugin: navigating to", key)

    -- Pre-stash for _setupQuranPopupButtons (won't fire for in-place update,
    -- but needed if showDict falls through to creating a new popup)
    self._last_ayah_surah = surah
    self._last_ayah_num = ayah

    -- Update mutable state on popup (button callbacks reference these)
    dict_popup._quran_pdf_surah = surah
    dict_popup._quran_pdf_ayah = ayah

    -- Update button enable/disable states
    local has_prev = ayah > 1 or surah > 1
    local has_next = ayah < (SURAH_AYAH_COUNTS[surah] or 0) or surah < 114
    local next_btn = dict_popup.button_table:getButtonById("next_ayah")
    local prev_btn = dict_popup.button_table:getButtonById("prev_ayah")
    if next_btn then next_btn:enableDisable(has_next) end
    if prev_btn then prev_btn:enableDisable(has_prev) end

    -- Capture current dictionary so in-place update stays in it
    dict_popup._quran_pdf_dict_name = dict_popup.dictionary

    -- Signal showDict to update this popup in-place
    DictQuickLookup._quran_pdf_update_popup = dict_popup

    -- Trigger lookup through normal pipeline
    self.ui.dictionary:onLookupWord(key)
end

--- Navigate to a specific surah overview. Updates the popup in-place.
function Quran:_lookupSurah(surah, dict_popup)
    local name = SURAH_NAMES[surah]
    if not name then return end

    logger.dbg("quran_pdf.koplugin: navigating to surah overview", surah, name)

    -- Update mutable state on popup (button callbacks reference this)
    dict_popup._quran_pdf_overview_surah = surah

    -- Update button enable/disable states
    local has_prev = surah > 1
    local has_next = surah < 114
    local next_btn = dict_popup.button_table:getButtonById("next_surah")
    local prev_btn = dict_popup.button_table:getButtonById("prev_surah")
    if next_btn then next_btn:enableDisable(has_next) end
    if prev_btn then prev_btn:enableDisable(has_prev) end

    -- Capture current dictionary so in-place update stays in it
    dict_popup._quran_pdf_dict_name = dict_popup.dictionary

    -- Signal showDict to update this popup in-place
    DictQuickLookup._quran_pdf_update_popup = dict_popup

    -- Trigger lookup through normal pipeline
    self.ui.dictionary:onLookupWord(name)
end

--- Common setup for all Quran custom popups.
-- Clears default buttons, sets flags for medium height and no word highlight.
-- Initializes text mode state from saved settings.
-- @param dict_popup DictQuickLookup instance
-- @param buttons Buttons table from _setupQuranPopupButtons
-- @param settings LuaSettings instance
local function setupQuranPopup(dict_popup, buttons, settings)
    if DictQuickLookup._quran_pdf_next_lookup then
        DictQuickLookup._quran_pdf_next_lookup = nil
    end
    -- Don't inherit temp large-window mode from a previous regular popup
    DictQuickLookup.temp_large_window_request = nil
    dict_popup._quran_pdf_popup = true
    dict_popup.word_boxes = nil
    for i = #buttons, 1, -1 do
        table.remove(buttons, i)
    end
    -- Text mode is auto-determined per dict type in the update() patch
end

--- Build a nav button pair (next/prev) respecting RTL/LTR setting.
-- RTL (default): ◁ = next (forward), ▷ = prev (backward)
-- LTR: ◁ = prev (backward), ▷ = next (forward)
-- @param self_quran Quran plugin instance (for accessing ReaderView)
-- @param next_btn table with id, enabled, callback for forward nav
-- @param prev_btn table with id, enabled, callback for backward nav
-- @return left_btn, right_btn (ready for button row insertion)
local function navButtons(self_quran, next_btn, prev_btn)
    -- Follow KOReader's page turn direction (inverse_reading_order = RTL)
    local rtl = self_quran.ui and self_quran.ui.view
        and self_quran.ui.view.inverse_reading_order
    if rtl then
        -- RTL: left=next(◁), right=prev(▷)
        next_btn.text = "◁"
        prev_btn.text = "▷"
        return next_btn, prev_btn
    else
        -- LTR: left=prev(◁), right=next(▷)
        prev_btn.text = "◁"
        next_btn.text = "▷"
        return prev_btn, next_btn
    end
end

--- Scroll-to-top button for Quran popups.
local function scrollTopButton(dict_popup)
    return {
        id = "scroll_top",
        text = "⇱",
        callback = function()
            if dict_popup.definition_widget and dict_popup.definition_widget[1] then
                if dict_popup.definition_widget[1].scrollToTop then
                    dict_popup.definition_widget[1]:scrollToTop()
                elseif dict_popup.definition_widget[1].scrollToRatio then
                    dict_popup.definition_widget[1]:scrollToRatio(0)
                end
            end
        end,
    }
end

--- Scroll-to-bottom button for Quran popups.
local function scrollBottomButton(dict_popup)
    return {
        id = "scroll_bottom",
        text = "⇲",
        callback = function()
            if dict_popup.definition_widget and dict_popup.definition_widget[1] then
                if dict_popup.definition_widget[1].scrollToBottom then
                    dict_popup.definition_widget[1]:scrollToBottom()
                elseif dict_popup.definition_widget[1].scrollToRatio then
                    dict_popup.definition_widget[1]:scrollToRatio(1)
                end
            end
        end,
    }
end

--- Detect surah:ayah from XPointers using CREngine HTML.
-- Works for per-ayah layouts where each ayah is wrapped in <p id="ayah-S-A">.
-- Returns surah (int), ayah (int) or nil, nil.
function Quran:_detectAyahFromXPointer(pos0, pos1)
    local pdf = self:_getPDF()
    if pdf then
        local hit = pdf:selection({pos0=pos0,pos1=pos1})
        if hit then return hit.surah, hit.ayah end
        return nil, nil
    end
    if not self.ui or not self.ui.document then
        return nil, nil
    end
    local doc = self.ui.document

    -- Try narrow range first (per-ayah/bilingual/wbw: ayah ID is on ancestor)
    local ok, html = pcall(function()
        return doc:getHTMLFromXPointers(pos0, pos1, 0x8000, true)
    end)
    if ok and html then
        local surah_str, ayah_str = html:match('ayah%-(%d+)%-(%d+)')
        if surah_str and ayah_str then
            logger.info("QURAN: detect: ancestor match", surah_str, ayah_str)
            return tonumber(surah_str), tonumber(ayah_str)
        end
    end

    -- For inline/continuous layouts: ayah ID is on a sibling <span> after the word.
    -- Extend range forward to include the next ayah marker in the HTML.
    local ok2, pageno = pcall(function()
        return doc:getPageFromXPointer(pos0)
    end)
    if not ok2 or not pageno then
        logger.info("QURAN: detect: could not get page")
        return nil, nil
    end

    local ok3, ext_xp = pcall(function()
        return doc:getPageXPointer(pageno + 3)
    end)
    if not ok3 or not ext_xp then
        -- Near end of document — try page + 1
        ok3, ext_xp = pcall(function()
            return doc:getPageXPointer(pageno + 1)
        end)
        if not ok3 or not ext_xp then
            logger.info("QURAN: detect: could not get extended xpointer")
            return nil, nil
        end
    end

    local ok4, ext_html = pcall(function()
        return doc:getHTMLFromXPointers(pos0, ext_xp, 0x20000, true)
    end)
    if ok4 and ext_html then
        local surah_str, ayah_str = ext_html:match('ayah%-(%d+)%-(%d+)')
        if surah_str and ayah_str then
            logger.info("QURAN: detect: extended match", surah_str, ayah_str)
            return tonumber(surah_str), tonumber(ayah_str)
        end
    end

    logger.info("QURAN: detect: no ayah found")
    return nil, nil
end

--- Filter word-lookup results down to the instance at the pressed position.
-- Consumes the XPointers stashed by onWordSelection, detects the pressed
-- word's surah:ayah, and keeps only results whose embedded
-- <!-- ref:S:A:W --> comment matches that ayah (instance-mode word
-- dictionaries). Returns results unchanged when detection fails or nothing
-- matches. Runs inside the showDict patch, before the popup is built, so it
-- works on all KOReader versions.
function Quran:_filterWordResultsByPosition(results)
    local pdf_reference = self._stashed_pdf_reference
    self._stashed_pdf_reference = nil
    local word_pos0 = self._stashed_word_pos0
    local word_pos1 = self._stashed_word_pos1
    self._stashed_word_pos0 = nil
    self._stashed_word_pos1 = nil

    if not (word_pos0 and word_pos1 and #results > 1) then
        return results
    end
    logger.info("QURAN: instance match:", #results, "results")
    local det_surah, det_ayah
    if pdf_reference then
        det_surah,det_ayah = pdf_reference[1],pdf_reference[2]
    else
        det_surah,det_ayah = self:_detectAyahFromXPointer(word_pos0, word_pos1)
    end
    if not (det_surah and det_ayah) then
        return results
    end
    local ref_prefix = det_surah .. ":" .. det_ayah .. ":"
    -- Keep only results whose ref matches this ayah
    local filtered = {}
    for _, result in ipairs(results) do
        if result.definition then
            local refs = result.definition:match("<!%-%- ref:(.-) %-%->")
            if refs then
                for ref in refs:gmatch("[^,]+") do
                    if ref:sub(1, #ref_prefix) == ref_prefix then
                        table.insert(filtered, result)
                        break
                    end
                end
            end
        end
    end
    if #filtered > 0 then
        logger.info("QURAN: filtered", #results, "->", #filtered, "results")
        return filtered
    end
    logger.info("QURAN: no ref matched prefix", ref_prefix)
    return results
end

--- Build the custom button layout for Quran popups (grammar / surah overview).
-- Replaces the default buttons with nav/scroll/text-mode rows, overrides
-- key handlers, and flags the popup for medium height. Leaves non-Quran
-- popups untouched (returns nil).
-- Reached via Quran:onDictButtonsReady (KOReader < 2026.05) or the
-- buildButtonLayout patch (newer versions).
-- @param dict_popup DictQuickLookup instance
-- @param buttons button-row table to fill (cleared first)
-- @return true if this was a Quran popup and the buttons were replaced
function Quran:_setupQuranPopupButtons(dict_popup, buttons)
    if not self:_getPDF() then return nil end
    -- Try parsing the lookup word first (works for prev/next navigation)
    local surah, ayah = parseQuranKey(dict_popup.word)

    -- Fall back to stashed info from onWordLookup (initial long-press case)
    if not surah and self._last_ayah_surah then
        surah = self._last_ayah_surah
        ayah = self._last_ayah_num
        self._last_ayah_surah = nil
        self._last_ayah_num = nil
    end

    -- Surah overview popup: [⇱] [◁ Next] [Close] [Prev ▷] [⇲]
    -- Navigation goes to next/prev surah overview
    if not surah or not ayah then
        if not DictQuickLookup._quran_pdf_next_lookup then return end

        local overview_surah = self._last_overview_surah
        self._last_overview_surah = nil

        logger.dbg("quran_pdf.koplugin: patching surah overview popup for surah", overview_surah)
        setupQuranPopup(dict_popup, buttons, self.settings)
        dict_popup._quran_pdf_overview_surah = overview_surah

        local has_prev = overview_surah and overview_surah > 1
        local has_next = overview_surah and overview_surah < 114

        local left_btn, right_btn = navButtons(self, {
            id = "next_surah",
            enabled = has_next,
            vsync = true,
            callback = function()
                local s = (dict_popup._quran_pdf_overview_surah or 0) + 1
                if s <= 114 then
                    self:_lookupSurah(s, dict_popup)
                end
            end,
        }, {
            id = "prev_surah",
            enabled = has_prev,
            vsync = true,
            callback = function()
                local s = (dict_popup._quran_pdf_overview_surah or 2) - 1
                if s >= 1 then
                    self:_lookupSurah(s, dict_popup)
                end
            end,
        })

        table.insert(buttons, {
            scrollTopButton(dict_popup),
            left_btn,
            textModeButton(dict_popup),
            right_btn,
            scrollBottomButton(dict_popup),
        })
        table.insert(buttons, {
            {
                id = "close",
                text = _("Close"),
                callback = function()
                    dict_popup:onClose()
                end,
            },
        })

        -- Volume/page-turn keys for surah navigation
        dict_popup.onReadNextResult = function(self_dql)
            local s = (self_dql._quran_pdf_overview_surah or 0) + 1
            if s <= 114 then
                self:_lookupSurah(s, self_dql)
            end
            return true
        end
        dict_popup.onReadPrevResult = function(self_dql)
            local s = (self_dql._quran_pdf_overview_surah or 2) - 1
            if s >= 1 then
                self:_lookupSurah(s, self_dql)
            end
            return true
        end

        return true  -- block VocabBuilder
    end

    -- Grammar dictionary popup: [⇱] [◁ Next] [TXT] [Prev ▷] [⇲]
    -- Navigation goes to next/prev ayah
    logger.dbg("quran_pdf.koplugin: patching grammar popup for", surah, ":", ayah)
    setupQuranPopup(dict_popup, buttons, self.settings)

    -- Store mutable state for button callbacks and key handlers
    dict_popup._quran_pdf_surah = surah
    dict_popup._quran_pdf_ayah = ayah

    local has_prev = ayah > 1 or surah > 1
    local has_next = ayah < (SURAH_AYAH_COUNTS[surah] or 0) or surah < 114

    -- Button rows:
    -- Row 1: [⇱] [◁/▷] [TXT ON/OFF] [▷/◁] [⇲]
    -- Row 2: [Close]
    -- Direction follows KOReader's inverse_reading_order setting
    local left_btn, right_btn = navButtons(self, {
        id = "next_ayah",
        enabled = has_next,
        vsync = true,
        callback = function()
            local s = dict_popup._quran_pdf_surah
            local a = dict_popup._quran_pdf_ayah + 1
            if a > (SURAH_AYAH_COUNTS[s] or 0) then
                s = s + 1; a = 1
            end
            if s <= 114 then
                self:_lookupAyah(s, a, dict_popup)
            end
        end,
    }, {
        id = "prev_ayah",
        enabled = has_prev,
        vsync = true,
        callback = function()
            local s = dict_popup._quran_pdf_surah
            local a = dict_popup._quran_pdf_ayah - 1
            if a < 1 then
                s = s - 1; a = SURAH_AYAH_COUNTS[s] or 1
            end
            if s >= 1 then
                self:_lookupAyah(s, a, dict_popup)
            end
        end,
    })

    table.insert(buttons, {
        scrollTopButton(dict_popup),
        left_btn,
        textModeButton(dict_popup),
        right_btn,
        scrollBottomButton(dict_popup),
    })
    table.insert(buttons, {
        {
            id = "close",
            text = _("Close"),
            callback = function()
                dict_popup:onClose()
            end,
        },
    })

    -- Override volume/page-turn keys for ayah navigation
    dict_popup.onReadNextResult = function(self_dql)
        local s = self_dql._quran_pdf_surah
        local a = self_dql._quran_pdf_ayah + 1
        if a > (SURAH_AYAH_COUNTS[s] or 0) then
            s = s + 1; a = 1
        end
        if s <= 114 then
            self:_lookupAyah(s, a, self_dql)
        end
        return true
    end
    dict_popup.onReadPrevResult = function(self_dql)
        local s = self_dql._quran_pdf_surah
        local a = self_dql._quran_pdf_ayah - 1
        if a < 1 then
            s = s - 1; a = SURAH_AYAH_COUNTS[s] or 1
        end
        if s >= 1 then
            self:_lookupAyah(s, a, self_dql)
        end
        return true
    end

    -- Block VocabBuilder from adding its button
    return true
end

--- DictButtonsReady event handler — KOReader < 2026.05 only.
-- Newer versions removed the event (#15184); they take the
-- buildButtonLayout patch path instead.
function Quran:onDictButtonsReady(dict_popup, buttons)
    return self:_setupQuranPopupButtons(dict_popup, buttons)
end

-- ---------------------------------------------------------------------------
-- Juz status bar
-- ---------------------------------------------------------------------------

--- Determine the current juz based on reading position.
-- Uses the TOC to find the current surah, then looks up which juz it falls in.
-- Caches result per page to avoid repeated TOC scans.
-- @return juz number (1-30), or nil if on front matter
-- @return boolean boundary — true if a juz boundary occurs on this page
function Quran:_getCurrentJuz()
    local pdf = self:_getPDF()
    if not pdf then return nil end
    local context = pdf:current(self.ui)
    if context then return context.j, context.b end
    return nil
end

function Quran:_getJuzTocPages()
    if self._juz_toc_pages then return self._juz_toc_pages end

    local toc = self.ui.toc
    if not toc then return nil end

    toc:fillToc()
    local toc_list = toc.toc
    if not toc_list or #toc_list == 0 then return nil end

    -- Pass 1: collect juz TOC pages and xpointers
    local juz_pages = {}
    local juz_xpointers = {}
    local count = 0
    for _, entry in ipairs(toc_list) do
        local page = entry.orig_page or entry.page
        if entry.title and page then
            local title = toc:cleanUpTocTitle(entry.title)
            -- Match "جزء ١" through "جزء ٣٠" (Arabic-Indic numerals)
            local after_juz = title:match("^جزء%s+(.+)$")
            if after_juz then
                local juz_num = arabicIndicToInt(after_juz)
                if not juz_num then
                    juz_num = tonumber(after_juz)
                end
                if juz_num and juz_num >= 1 and juz_num <= 30 then
                    juz_pages[juz_num] = page
                    juz_xpointers[juz_num] = entry.xpointer
                    count = count + 1
                end
            end
        end
    end

    if count == 0 then
        logger.dbg("quran_pdf.koplugin: NO juz TOC entries found!")
        return nil
    end

    -- Pass 2: try to get more accurate pages from the page map.
    -- Mushaf page markers (<span id="pageNNN">) are BEFORE the ayah block
    -- in our templates, so they resolve to the page where the content starts
    -- — even when anti-orphan pushes the block element to the next page.
    local doc = self.ui.document
    if doc and doc.hasPageMap and doc:hasPageMap() then
        local page_map = doc:getPageMap()
        if page_map and #page_map > 0 then
            -- Build mushaf label → CRE page lookup
            local label_to_cre = {}
            for _, pm in ipairs(page_map) do
                if pm.label and pm.page then
                    label_to_cre[pm.label] = pm.page
                end
            end
            -- For each juz, find its mushaf page label via its xpointer
            local upgraded = 0
            for j = 1, 30 do
                if juz_xpointers[j] then
                    local ok, label = pcall(doc.getPageMapXPointerPageLabel, doc, juz_xpointers[j])
                    if ok and label and label_to_cre[label] then
                        local marker_page = label_to_cre[label]
                        if marker_page ~= juz_pages[j] then
                            logger.dbg("quran_pdf.koplugin: juz", j,
                                "page marker", label, "-> page", marker_page,
                                "(was", juz_pages[j], "from TOC anchor)")
                        end
                        juz_pages[j] = marker_page
                        upgraded = upgraded + 1
                    end
                end
            end
            if upgraded > 0 then
                logger.dbg("quran_pdf.koplugin: upgraded", upgraded, "juz pages from page map")
            end
        end
    end

    self._juz_toc_pages = juz_pages
    local parts = {}
    for j = 1, 30 do
        if juz_pages[j] then
            table.insert(parts, j .. "=" .. juz_pages[j])
        end
    end
    logger.dbg("quran_pdf.koplugin: juz pages:", table.concat(parts, " "))
    return juz_pages
end

--- Find the current surah number from reading position (page-based).
-- Lighter than _findSurahForPosition (no xpointer needed).
-- IMPORTANT: Uses entry.orig_page when available. KOReader's
-- validateAndFixToc() may corrupt surah entry page numbers because
-- our nav TOC has juz entries (high pages) before surah entries
-- (low pages), which triggers the "bogus page" fixer.
function Quran:_findSurahForPage(pageno)
    local toc = self.ui.toc
    if not toc then return nil end

    toc:fillToc()
    local toc_list = toc.toc
    if not toc_list or #toc_list == 0 then return nil end

    local best_surah = nil
    for _, entry in ipairs(toc_list) do
        local page = entry.orig_page or entry.page
        if page and page <= pageno and entry.title then
            local title = toc:cleanUpTocTitle(entry.title)
            local surah_num = extractSurahInfo(title)
            if surah_num then
                best_surah = surah_num
            end
        end
    end
    return best_surah
end

--- Convert integer to Arabic-Indic numeral string.
local function toArabicIndic(n)
    local digits = {"٠","١","٢","٣","٤","٥","٦","٧","٨","٩"}
    local result = ""
    for ch in tostring(n):gmatch(".") do
        local d = tonumber(ch)
        result = result .. digits[d + 1]
    end
    return result
end

--- Format a juz number according to the display format key.
-- @param juz number: juz number (1-30)
-- @param juz_display string: format key
-- @return string, bool: formatted string, whether the format is Arabic/RTL
function Quran:_formatJuzString(juz, juz_display)
    local juz_str
    if juz_display == "name_arabic" then
        juz_str = (JUZ_NAMES_ARABIC[juz] or "")
    elseif juz_display == "name_arabic_with_juz" then
        juz_str = "جزء " .. (JUZ_NAMES_ARABIC[juz] or "")
    elseif juz_display == "ordinal_arabic" then
        juz_str = "الجزء " .. (JUZ_ORDINAL_ARABIC[juz] or "")
    elseif juz_display == "number_latin" then
        juz_str = "Juz " .. juz
    elseif juz_display == "name_latin" then
        juz_str = (JUZ_NAMES_LATIN[juz] or "")
    elseif juz_display == "name_latin_with_juz" then
        juz_str = "Juz' " .. (JUZ_NAMES_LATIN[juz] or "")
    else -- "number_arabic" (default)
        juz_str = "جزء " .. toArabicIndic(juz)
    end
    local is_arabic = juz_display == "number_arabic" or juz_display == "name_arabic"
                      or juz_display == "name_arabic_with_juz"
                      or juz_display == "ordinal_arabic"
    return juz_str, is_arabic
end

--- Build display string with juz and optional surah.
-- @param opts table with keys: juz_display, show_surah, surah_display
function Quran:_buildDisplayString(opts)
    local juz, boundary = self:_getCurrentJuz()
    if not juz then return end

    local mark = boundary and "*" or ""
    local juz_str, is_arabic = self:_formatJuzString(juz, opts.juz_display)

    local segments = { juz_str .. mark }

    -- Surah name (always last)
    if opts.show_surah then
        local surah = self:_getCurrentSurah()
        if surah then
            local surah_name
            local use_arabic = opts.surah_display == "arabic"
                or opts.surah_display == "arabic_with_surat"
                or (opts.surah_display == "auto" and is_arabic)
            if use_arabic then
                surah_name = SURAH_NAMES_ARABIC[surah]
                if surah_name and opts.surah_display == "arabic_with_surat" then
                    surah_name = "سورة " .. surah_name
                end
            else
                surah_name = SURAH_NAMES[surah]
                if surah_name and opts.surah_display == "latin_with_surat" then
                    surah_name = "Surat " .. surah_name
                end
            end
            if surah_name then
                table.insert(segments, surah_name)
            end
        end
    end

    local result = table.concat(segments, " · ")

    -- Wrap RTL if juz format is Arabic, OR if surah name is Arabic
    local surah_is_arabic = opts.surah_display == "arabic" or opts.surah_display == "arabic_with_surat"
        or (opts.surah_display == "auto" and is_arabic)
    local needs_bidi = is_arabic or (surah_is_arabic and opts.show_surah)
    if needs_bidi then
        return BD.wrap(result)
    else
        return result
    end
end

--- Format display string for footer status bar (juz and surah by default).
function Quran:_getJuzFooterString()
    return self:_buildDisplayString({
        juz_display = self.settings:readSetting("juz_display", "number_arabic"),
        show_surah = self.settings:nilOrTrue("show_surah_in_footer"),
        surah_display = self.settings:readSetting("surah_display", "auto"),
    })
end

--- Format display string for header bar (right side only, surah is on left).
function Quran:_getJuzHeaderString()
    return self:_buildDisplayString({
        juz_display = self.settings:readSetting("header_juz_display", "ordinal_arabic"),
        show_surah = false,
    })
end

--- Get current surah number (cached per page).
function Quran:_getCurrentSurah()
    local pdf = self:_getPDF()
    if not pdf then return nil end
    local context = pdf:current(self.ui)
    return context and context.s
end

--- Invalidate caches on page turn.
function Quran:onPageUpdate()
    self._cached_pageno = nil
    self._cached_juz = nil
    self._cached_boundary = nil
    self._cached_surah_pg = nil
    self._cached_surah = nil
end

function Quran:onPosUpdate()
    self._cached_pageno = nil
    self._cached_juz = nil
    self._cached_boundary = nil
    self._cached_surah_pg = nil
    self._cached_surah = nil
end

-- Status bar registration helpers (following ReadTimer pattern)

function Quran:_addFooterContent()
    if self.ui.view then
        self.ui.view.footer:addAdditionalFooterContent(self.additional_footer_content_func)
        UIManager:broadcastEvent(Event:new("UpdateFooter", true))
    end
end

function Quran:_removeFooterContent()
    if self.ui.view then
        self.ui.view.footer:removeAdditionalFooterContent(self.additional_footer_content_func)
        UIManager:broadcastEvent(Event:new("UpdateFooter", true))
    end
end

function Quran:_addHeaderContent()
    if not self.ui.crelistener then return end
    logger.info("quran_pdf.koplugin: registering header content, status_line:",
                self.document.configurable.status_line,
                "view_mode:", self.view.view_mode)
    self.ui.crelistener:addAdditionalHeaderContent(self.additional_header_content_func)
    -- Edge case: if the user has disabled ALL built-in alt status bar items,
    -- CREngine allocates 0px for the header (m_pageHeaderInfo == 0).
    -- Force a flag so space is allocated; setPageInfoOverride() replaces
    -- the built-in rendering, so the forced flag has no visible side effect
    -- beyond the progress bar (which is always drawn anyway).
    self:_ensureHeaderSpace()
    UIManager:broadcastEvent(Event:new("UpdateHeader"))
end

function Quran:_removeHeaderContent()
    if not self.ui.crelistener then return end
    self.ui.crelistener:removeAdditionalHeaderContent(self.additional_header_content_func)
    UIManager:broadcastEvent(Event:new("UpdateHeader"))
end

--- Ensure CREngine allocates header space even if no built-in items are enabled.
-- When all built-in alt status bar items are off, m_pageHeaderInfo == 0 and
-- CREngine returns 0 from getPageHeaderHeight(), so the header is invisible.
-- We force PGHDR_PAGE_NUMBER (1) directly via setHeaderInfo to allocate space;
-- setPageInfoOverride() replaces the built-in page number rendering with our
-- content, so the forced flag has no visible side effect beyond the progress bar.
function Quran:_ensureHeaderSpace()
    if not self.ui.crelistener then return end
    local cl = self.ui.crelistener
    local any_builtin = cl.title == 1 or cl.author == 1 or cl.clock == 1
        or cl.page_number == 1 or cl.page_count == 1 or cl.reading_percent == 1
        or cl.chapter_marks == 1
        or (cl.battery == 1 and cl.battery_percent == 1)
    if not any_builtin then
        logger.info("quran_pdf.koplugin: no built-in header items enabled, forcing PGHDR_PAGE_NUMBER for header space")
        -- Use setHeaderInfo to directly set m_pageHeaderInfo, bypassing the
        -- property system (setIntProperty goes through propsApply but may
        -- not reliably update the bitfield)
        self.ui.document._document:setHeaderInfo(1) -- PGHDR_PAGE_NUMBER
    end
end

-- ---------------------------------------------------------------------------
-- Header overlay (pure Lua, independent of CREngine alt status bar)
-- ---------------------------------------------------------------------------

--- Hook ReaderView.paintTo to draw our header overlay after normal rendering.
function Quran:_setupHeaderOverlay()
    if self._header_overlay_hooked then return end
    self._header_overlay_hooked = true

    local quran = self
    local orig_paintTo = self.ui.view.paintTo
    self.ui.view.paintTo = function(view_self, bb, x, y)
        orig_paintTo(view_self, bb, x, y)
        if quran._header_overlay_enabled and quran._is_quran_book then
            quran:_drawHeaderOverlay(bb, x, y)
        end
    end
end

--- Build and paint the header overlay: surah (left) — juz (right).
function Quran:_drawHeaderOverlay(bb, x, y)
    local screen_width = Screen:getWidth()
    local margin = Math.round(screen_width * 0.02) -- 2% side margins

    -- Font size from settings (default 16)
    local font_size = self.settings:readSetting("header_font_size", 10)
    local face = Font:getFace("cfont", font_size)

    -- Text color from gray level setting (0 = black, 10 = light gray)
    local gray_level = self.settings:readSetting("header_text_gray", 5)
    local gray_byte = math.min(gray_level * 25, 250)
    local text_color = Blitbuffer.colorFromString(string.format("#%02x%02x%02x", gray_byte, gray_byte, gray_byte))

    -- Build left side (surah)
    local left_text = nil
    if self.settings:nilOrTrue("header_show_surah") then
        local surah = self:_getCurrentSurah()
        if surah then
            local surah_display = self.settings:readSetting("header_surah_display", "arabic_with_surat")
            local surah_name
            if surah_display == "arabic" then
                surah_name = SURAH_NAMES_ARABIC[surah]
            elseif surah_display == "arabic_with_surat" then
                surah_name = SURAH_NAMES_ARABIC[surah]
                if surah_name then surah_name = "سورة " .. surah_name end
            elseif surah_display == "latin_with_surat" then
                surah_name = SURAH_NAMES[surah]
                if surah_name then surah_name = "Surat " .. surah_name end
            elseif surah_display == "latin" then
                surah_name = SURAH_NAMES[surah]
            else -- auto: default to arabic for header
                surah_name = SURAH_NAMES_ARABIC[surah]
            end
            if surah_name then
                left_text = BD.auto(surah_name)
            end
        end
    end

    -- Build right side (juz + optional metadata)
    local right_text = nil
    local juz, boundary = self:_getCurrentJuz()
    if juz then
        local mark = boundary and "*" or ""
        local juz_display = self.settings:readSetting("header_juz_display", "ordinal_arabic")
        local juz_str = self:_formatJuzString(juz, juz_display)
        right_text = BD.auto(juz_str .. mark)
    end

    if not left_text and not right_text then return end

    -- Create text widgets
    local max_item_width = math.floor((screen_width - margin * 3) / 2)
    local left_widget = left_text and TextWidget:new{
        text = left_text,
        face = face,
        max_width = max_item_width,
        fgcolor = text_color,
        padding = 0,
    }
    local right_widget = right_text and TextWidget:new{
        text = right_text,
        face = face,
        max_width = max_item_width,
        fgcolor = text_color,
        padding = 0,
    }

    -- Calculate layout
    local left_w = left_widget and left_widget:getSize().w or 0
    local right_w = right_widget and right_widget:getSize().w or 0
    local spacer_w = math.max(0, screen_width - margin * 2 - left_w - right_w)

    -- Build horizontal group
    local items = {}
    table.insert(items, HorizontalSpan:new{ width = margin })
    if left_widget then
        table.insert(items, left_widget)
    end
    table.insert(items, HorizontalSpan:new{ width = spacer_w })
    if right_widget then
        table.insert(items, right_widget)
    end

    local header_height = math.max(
        left_widget and left_widget:getSize().h or 0,
        right_widget and right_widget:getSize().h or 0
    )

    local header = HorizontalGroup:new(items)
    header:paintTo(bb, x, y)

    -- Free widgets
    header:free()
end

-- ---------------------------------------------------------------------------
-- Menu
-- ---------------------------------------------------------------------------

function Quran:addToMainMenu(menu_items)
    -- Display labels for format pickers
    local juz_displays = {
        number_arabic = "جزء ٣٠",
        name_arabic_with_juz = "جزء عم",
        ordinal_arabic = "الجزء الثلاثون",
        name_arabic = "عم",
        number_latin = "Juz 30",
        name_latin_with_juz = "Juz' 'Amma",
        name_latin = "'Amma",
    }
    local surah_displays = {
        auto = _("auto"),
        arabic = "الفاتحة",
        arabic_with_surat = "سورة الفاتحة",
        latin = "Al-Fatihah",
        latin_with_surat = "Surat Al-Fatihah",
    }

    -- Helper: build juz format radio items for a given settings key
    local function juzFormatItems(key, default, update_footer, update_header)
        local function save(value)
            self.settings:saveSetting(key, value)
            self.settings:flush()
            if update_footer then UIManager:broadcastEvent(Event:new("UpdateFooter", true)) end
            if update_header then UIManager:broadcastEvent(Event:new("UpdateHeader")) end
        end
        return {
            {
                text = "جزء ١، جزء ٢، ... جزء ٣٠",
                checked_func = function() return self.settings:readSetting(key, default) == "number_arabic" end,
                radio = true,
                callback = function() save("number_arabic") end,
            },
            {
                text = "جزء عم، جزء تبارك، ... جزء آلم",
                checked_func = function() return self.settings:readSetting(key, default) == "name_arabic_with_juz" end,
                radio = true,
                callback = function() save("name_arabic_with_juz") end,
            },
            {
                text = "الجزء الأول، الجزء الثاني، ... الجزء الثلاثون",
                checked_func = function() return self.settings:readSetting(key, default) == "ordinal_arabic" end,
                radio = true,
                callback = function() save("ordinal_arabic") end,
            },
            {
                text = "عم، تبارك، ... آلم",
                checked_func = function() return self.settings:readSetting(key, default) == "name_arabic" end,
                radio = true,
                callback = function() save("name_arabic") end,
            },
            {
                text = "Juz 1, Juz 2, ... Juz 30",
                checked_func = function() return self.settings:readSetting(key, default) == "number_latin" end,
                radio = true,
                callback = function() save("number_latin") end,
            },
            {
                text = "Juz' 'Amma, Juz' Tabaraka, ... Juz' Alif Lam Mim",
                checked_func = function() return self.settings:readSetting(key, default) == "name_latin_with_juz" end,
                radio = true,
                callback = function() save("name_latin_with_juz") end,
            },
            {
                text = "'Amma, Tabaraka, ... Alif Lam Mim",
                checked_func = function() return self.settings:readSetting(key, default) == "name_latin" end,
                radio = true,
                callback = function() save("name_latin") end,
            },
        }
    end

    -- Helper: build surah format radio items for a given settings key
    local function surahFormatItems(key, default, update_footer, update_header)
        local function save(value)
            self.settings:saveSetting(key, value)
            self.settings:flush()
            if update_footer then UIManager:broadcastEvent(Event:new("UpdateFooter", true)) end
            if update_header then UIManager:broadcastEvent(Event:new("UpdateHeader")) end
        end
        return {
            {
                text = _("Auto (match juz format)"),
                help_text = _("Arabic name with Arabic juz formats, Latin name with Latin juz formats."),
                checked_func = function() return self.settings:readSetting(key, default) == "auto" end,
                radio = true,
                callback = function() save("auto") end,
            },
            {
                text = "الفاتحة، البقرة، ...",
                checked_func = function() return self.settings:readSetting(key, default) == "arabic" end,
                radio = true,
                callback = function() save("arabic") end,
            },
            {
                text = "سورة الفاتحة، سورة البقرة، ...",
                checked_func = function() return self.settings:readSetting(key, default) == "arabic_with_surat" end,
                radio = true,
                callback = function() save("arabic_with_surat") end,
            },
            {
                text = "Al-Fatihah, Al-Baqarah, ...",
                checked_func = function() return self.settings:readSetting(key, default) == "latin" end,
                radio = true,
                callback = function() save("latin") end,
            },
            {
                text = "Surat Al-Fatihah, Surat Al-Baqarah, ...",
                checked_func = function() return self.settings:readSetting(key, default) == "latin_with_surat" end,
                radio = true,
                callback = function() save("latin_with_surat") end,
            },
        }
    end

    menu_items.quran_pdf = {
        text = _("Quran PDF Helper"),
        sorting_hint = "tools",
        sub_item_table = {
            -- Grammar dictionary lookup toggle
            {
                text = _("Grammar dictionary lookup"),
                help_text = _("Long-press an ayah number marker to look up word-by-word grammar analysis. Requires a Quran grammar StarDict dictionary in data/dict/."),
                checked_func = function()
                    return self.settings:nilOrTrue("grammar_lookup")
                end,
                callback = function()
                    if self.settings:nilOrTrue("grammar_lookup") then
                        self.settings:saveSetting("grammar_lookup", false)
                    else
                        self.settings:saveSetting("grammar_lookup", true)
                    end
                    self.settings:flush()
                end,
            },
            -- Footer status bar submenu
            {
                text = _("Status bar"),
                sub_item_table = {
                    {
                        text = _("Show juz in status bar"),
                        help_text = _("Shows current juz in the footer status bar. Requires 'External content' to be enabled in Status bar settings (top menu → gear icon → Status bar → Status bar items → toggle 'External content')."),
                        checked_func = function()
                            return self.settings:nilOrTrue("show_juz_in_footer")
                        end,
                        callback = function()
                            if self.settings:nilOrTrue("show_juz_in_footer") then
                                self.settings:saveSetting("show_juz_in_footer", false)
                                self:_removeFooterContent()
                            else
                                self.settings:saveSetting("show_juz_in_footer", true)
                                self:_addFooterContent()
                            end
                            self.settings:flush()
                        end,
                    },
                    {
                        text_func = function()
                            local current = self.settings:readSetting("juz_display", "number_arabic")
                            return _("Juz format: ") .. (juz_displays[current] or "جزء ٣٠")
                        end,
                        help_text = _("Choose how the juz is displayed in the footer status bar. An asterisk (*) appears at juz boundaries."),
                        enabled_func = function()
                            return self.settings:nilOrTrue("show_juz_in_footer")
                        end,
                        sub_item_table = juzFormatItems("juz_display", "number_arabic", true, false),
                    },
                    {
                        text = _("Append surah name"),
                        help_text = _("Appends the current surah name after the juz display (e.g. 'جزء ١ · الفاتحة'). Enabled by default."),
                        enabled_func = function()
                            return self.settings:nilOrTrue("show_juz_in_footer")
                        end,
                        checked_func = function()
                            return self.settings:nilOrTrue("show_surah_in_footer")
                        end,
                        callback = function()
                            if self.settings:nilOrTrue("show_surah_in_footer") then
                                self.settings:saveSetting("show_surah_in_footer", false)
                            else
                                self.settings:saveSetting("show_surah_in_footer", true)
                            end
                            self.settings:flush()
                            UIManager:broadcastEvent(Event:new("UpdateFooter", true))
                        end,
                    },
                    {
                        text_func = function()
                            local current = self.settings:readSetting("surah_display", "auto")
                            return _("Surah format: ") .. (surah_displays[current] or _("auto"))
                        end,
                        help_text = _("Choose how the surah name is displayed in the footer. 'Auto' matches the juz format language."),
                        enabled_func = function()
                            return self.settings:nilOrTrue("show_juz_in_footer")
                                and self.settings:nilOrTrue("show_surah_in_footer")
                        end,
                        sub_item_table = surahFormatItems("surah_display", "auto", true, false),
                    },
                },
            },
            -- Header overlay submenu
            {
                text = _("Header bar"),
                sub_item_table = {
                    {
                        text = _("Show header bar"),
                        help_text = _("Shows surah name (left) and juz info (right) at the top of the page. This is an overlay — adjust the book's top margin to avoid overlap."),
                        checked_func = function()
                            return self.settings:isTrue("show_header_overlay")
                        end,
                        callback = function()
                            if self.settings:isTrue("show_header_overlay") then
                                self.settings:saveSetting("show_header_overlay", false)
                                self._header_overlay_enabled = false
                            else
                                self.settings:saveSetting("show_header_overlay", true)
                                self._header_overlay_enabled = true
                            end
                            self.settings:flush()
                            UIManager:setDirty(self.ui.view, "ui")
                        end,
                    },
                    {
                        text_func = function()
                            local current = self.settings:readSetting("header_juz_display", "ordinal_arabic")
                            return _("Juz format: ") .. (juz_displays[current] or "الجزء الثلاثون")
                        end,
                        help_text = _("Choose how the juz is displayed in the header bar. An asterisk (*) appears at juz boundaries."),
                        enabled_func = function()
                            return self.settings:isTrue("show_header_overlay")
                        end,
                        sub_item_table = juzFormatItems("header_juz_display", "ordinal_arabic", false, false),
                    },
                    {
                        text = _("Show surah name"),
                        help_text = _("Shows the current surah name on the left side of the header bar."),
                        enabled_func = function()
                            return self.settings:isTrue("show_header_overlay")
                        end,
                        checked_func = function()
                            return self.settings:nilOrTrue("header_show_surah")
                        end,
                        callback = function()
                            if self.settings:nilOrTrue("header_show_surah") then
                                self.settings:saveSetting("header_show_surah", false)
                            else
                                self.settings:saveSetting("header_show_surah", true)
                            end
                            self.settings:flush()
                            UIManager:setDirty(self.ui.view, "ui")
                        end,
                    },
                    {
                        text_func = function()
                            local current = self.settings:readSetting("header_surah_display", "arabic_with_surat")
                            return _("Surah format: ") .. (surah_displays[current] or "سورة الفاتحة")
                        end,
                        help_text = _("Choose how the surah name is displayed in the header bar."),
                        enabled_func = function()
                            return self.settings:isTrue("show_header_overlay")
                                and self.settings:nilOrTrue("header_show_surah")
                        end,
                        sub_item_table = surahFormatItems("header_surah_display", "arabic_with_surat", false, false),
                    },
                    {
                        text_func = function()
                            return _("Font size: ") .. self.settings:readSetting("header_font_size", 10)
                        end,
                        enabled_func = function()
                            return self.settings:isTrue("show_header_overlay")
                        end,
                        callback = function(touchmenu_instance)
                            local spin = SpinWidget:new{
                                value = self.settings:readSetting("header_font_size", 10),
                                value_min = 8,
                                value_max = 30,
                                default_value = 10,
                                title_text = _("Header font size"),
                                callback = function(spin)
                                    self.settings:saveSetting("header_font_size", spin.value)
                                    self.settings:flush()
                                    UIManager:setDirty(self.ui.view, "ui")
                                    if touchmenu_instance then touchmenu_instance:updateItems() end
                                end,
                            }
                            UIManager:show(spin)
                        end,
                        keep_menu_open = true,
                    },
                    {
                        text_func = function()
                            local gray = self.settings:readSetting("header_text_gray", 5)
                            if gray == 0 then
                                return _("Text gray: black")
                            else
                                return _("Text gray: ") .. gray
                            end
                        end,
                        help_text = _("Adjust text lightness. 0 = black (default), higher = lighter gray."),
                        enabled_func = function()
                            return self.settings:isTrue("show_header_overlay")
                        end,
                        callback = function(touchmenu_instance)
                            local spin = SpinWidget:new{
                                value = self.settings:readSetting("header_text_gray", 5),
                                value_min = 0,
                                value_max = 10,
                                default_value = 5,
                                title_text = _("Header text gray level"),
                                info_text = _("0 = black, 10 = light gray"),
                                callback = function(spin)
                                    self.settings:saveSetting("header_text_gray", spin.value)
                                    self.settings:flush()
                                    UIManager:setDirty(self.ui.view, "ui")
                                    if touchmenu_instance then touchmenu_instance:updateItems() end
                                end,
                            }
                            UIManager:show(spin)
                        end,
                        keep_menu_open = true,
                    },
                },
            },
        },
    }
end

function Quran:onCloseDocument()
    if self._quran_pdf_cover_refresh_pending then
        local file = self._quran_pdf_cover_refresh_pending
        if self:_refreshLibraryCover(file) and self.ui and self.ui.doc_settings then
            self.ui.doc_settings:saveSetting("quran_pdf_cover_cache_revision", BUNDLED_COVER_REVISION)
        end
        self._quran_pdf_cover_refresh_pending = nil
    end
    local guard = self._upstream_pdf_guard
    if guard then
        guard.instance._detectQuranBook = guard.detect
        guard.instance._setupQuranPopupButtons = guard.buttons
        self._upstream_pdf_guard = nil
    end
    self:_removeFooterContent()
    self._header_overlay_enabled = false
    self._is_quran_book = false
    if _active_quran_pdf == self then
        _active_quran_pdf = nil
        DictQuickLookup._quran_pdf_next_lookup = nil
        DictQuickLookup._quran_pdf_update_popup = nil
    end
    self._pdf = nil
end

return Quran
